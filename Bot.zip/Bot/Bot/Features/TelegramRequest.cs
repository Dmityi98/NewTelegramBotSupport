﻿using Telegram.Bot.Types;

namespace SupportBot.Features
{
    public record TelegramRequest(Update Update);
}
