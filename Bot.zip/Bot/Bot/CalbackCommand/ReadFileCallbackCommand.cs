﻿using Bot.Core.Models;
using Bot.Interface;
using Bot.Logic.Builder;
using System.Reflection.Metadata;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace Bot.CalbackCommand
{
    public class ReadFileCallbackCommand : ICallbackCommand
    {
        private readonly ITelegramBotClient _botClient;
        private readonly ReportBuilder _reportBuilder = new ReportBuilder();
        public  Dictionary<long, string> _filePaths = new();



        public ReadFileCallbackCommand(ITelegramBotClient botClient, ReportBuilder reportBuilder)
        {
            _botClient = botClient;
            _reportBuilder = reportBuilder;

        }
        public bool CanExecute(CallbackQuery callback)
        {
            return callback.Data.Equals("read", StringComparison.OrdinalIgnoreCase);
        }

        public async Task ExecuteAsync(ITelegramBotClient botClient, CallbackQuery callback, CancellationToken cancellationToken)
        {
            if (callback.Message is not { } message)
                return;

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "Идёт обработка файла и формирование отчета...",
                cancellationToken: cancellationToken);

            // Получаем путь к файлу из временного хранилища
            if (_filePaths.TryGetValue(message.Chat.Id, out var filePath))
            {
                // Обрабатываем файл
                _reportBuilder.FileExcelRead(filePath);
                var tlist = _reportBuilder.GetTeacherList();
                string NameTeachersStr = string.Join("\n", tlist.Select(n => n.NameTeacher));

                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: NameTeachersStr,
                    cancellationToken: cancellationToken);
            }
            else
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Файл не найден.",
                    cancellationToken: cancellationToken);
            }
        }
    }
}
