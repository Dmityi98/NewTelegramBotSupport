﻿namespace Bot.Logic.Builder
{
    public class Report
    {
    }
}
